require 'spec_helper'

describe MicropostsController do


   describe "access control" do

    it "should deny access to 'create'" do
      post :create
      response.should redirect_to(signin_path)
    end

    it "should deny access to 'destroy'" do
      delete :destroy, :id => 1
      response.should redirect_to(signin_path)
    end
  end

  describe "POST 'create'" do

    before(:each) do
      @user = signin_path(Factory(:user))
    end

    describe "failure" do

      before(:each) do
        @attr = { :content => "" }
      end

      it "should not create a micropost" do
        lambda do
          post :create, :micropost => @attr
        end.should_not change(Micropost, :count)
      end

      it "should render the home page" do
        post :create, :micropost => @attr
        response.should redirect_to(signin_path)
      end
    end

    describe "success" do

      before(:each) do
        @attr = { :content => "Content" }
      end

      it "should create a micropost" do
        lambda {
          post :create, :micropost => @attr
        should change(Micropost, :count).by(1)}
      end

      it "should redirect to the home page" do
        post :create, :micropost => @attr
        response.should redirect_to(signin_path)
      end

    end
  end
end